# DisasterSim — Daytona HackSprint Tokyo MVP

**A fictional flood-response route simulator.** This is **NOT** a real-world evacuation planning tool. It has no real hazard maps, actual road closures, population movement, accessibility or verified safety data.

## Windows PowerShell start

Install Python 3.11+ if needed; then open PowerShell from this directory:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:DAYTONA_API_KEY="your_daytona_api_key"
$env:NOSANA_URL="your_nosana_deployment_endpoint_url"
streamlit run app.py
```

If PowerShell blocks activation, instead use:

```powershell
py -m pip install -r requirements.txt
py -m streamlit run app.py
```

The UI works with no keys in **local demo** mode, but **that is not sponsor integration**. To show sponsor usage in a judged demo, provision keys and turn on Daytona execution, then click **Nosana AI explanation** and confirm actual responses.

## Architecture

1. User changes fictional flood intensity and starting location.
2. `sim_engine.py` uses deterministic grid risk and risk-weighted Dijkstra for routes to three fictional shelters.
3. `sponsors.py` runs the SAME simulation in a Daytona sandbox and parses the JSON result. The sandbox is deleted when complete.
4. The result is visualized in Streamlit, including a distance-only baseline.
5. We deployed an open LLM with Ollama on a Nosana GPU (RTX 3090). The app calls that deployment through its OpenAI-compatible API (`NOSANA_URL/v1`), picks the served model, and explains the grounded result with the fictional-data limitation.

For Daytona sandbox provisioning failures, check organization / default region and the API key in the Daytona dashboard. Daytona **CLI is not required** by this app. Daytona SDK version is pinned to the official v2 quickstart. Nosana model availability may change.

## Pitch (30 sec)

> In disasters, the shortest route isn't always the safest. DisasterSim lets you see the difference: when flooding intensifies, our simulation re-routes to reduce exposure to risk. Daytona runs the actual route calculation inside an isolated sandbox, and Nosana explains the trade-off using an open model. Today this is a fictional simulation, not emergency guidance. The long-term vision is to connect validated municipal hazard maps and emergency alerts.

## Judging honesty

Do not claim to support real-time rescue, actual safe routes, real evacuation times, or integrated sponsor products until the APIs really work.
